from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from ..core.database import get_db
from ..schemas.schemas import (
    SolicitacaoMatriculaCreate, 
    MatriculaResponse,
    ComprovanteMatricula,
    Turma,
    Matricula
)
from ..services.matricula_service import MatriculaService
from ..models.models import Turma as TurmaModel, Matricula as MatriculaModel

router = APIRouter(prefix="/matricula", tags=["matricula"])

@router.post("/confirmar-pre-matricula", response_model=MatriculaResponse)
def confirmar_pre_matricula(
    aluno_matricula: str,
    turma_id: int,
    aceitar: bool,
    db: Session = Depends(get_db)
):
    """Fase 2: Confirmar ou rejeitar pré-matrícula"""
    service = MatriculaService(db)
    result = service.confirmar_pre_matricula(aluno_matricula, turma_id, aceitar)
    return MatriculaResponse(**result)

@router.post("/solicitar-turma", response_model=MatriculaResponse)
def solicitar_turma_adicional(
    solicitacao: SolicitacaoMatriculaCreate,
    db: Session = Depends(get_db)
):
    """Fase 2, 4, 6: Solicitar turma adicional"""
    service = MatriculaService(db)
    result = service.solicitar_turma_adicional(solicitacao)
    return MatriculaResponse(**result)

@router.post("/processar-lote/{fase}", response_model=MatriculaResponse)
def processar_solicitacoes_lote(
    fase: str,
    db: Session = Depends(get_db)
):
    """Fase 3, 5: Processar solicitações em lote"""
    if fase not in ["Matricula", "Rematricula"]:
        raise HTTPException(status_code=400, detail="Fase inválida")
    
    service = MatriculaService(db)
    result = service.processar_solicitacoes_batch(fase)
    return MatriculaResponse(
        success=True, 
        message=f"Processadas {result['processadas']} solicitações",
        data=result
    )

@router.post("/matricula-extraordinaria", response_model=MatriculaResponse)
def matricula_extraordinaria(
    solicitacao: SolicitacaoMatriculaCreate,
    db: Session = Depends(get_db)
):
    """Fase 6: Matrícula extraordinária"""
    # Forçar fase como Extraordinaria
    solicitacao.fase = "Extraordinaria"
    
    service = MatriculaService(db)
    result = service.matricula_extraordinaria(solicitacao)
    return MatriculaResponse(**result)

@router.delete("/cancelar/{aluno_matricula}/{turma_id}", response_model=MatriculaResponse)
def cancelar_matricula(
    aluno_matricula: str,
    turma_id: int,
    db: Session = Depends(get_db)
):
    """Fase 4: Cancelar matrícula"""
    service = MatriculaService(db)
    result = service.cancelar_matricula(aluno_matricula, turma_id)
    return MatriculaResponse(**result)

@router.get("/comprovante/{aluno_matricula}/{periodo_letivo}")
def obter_comprovante(
    aluno_matricula: str,
    periodo_letivo: str,
    db: Session = Depends(get_db)
):
    """Fase 7: Gerar comprovante de matrícula"""
    service = MatriculaService(db)
    result = service.obter_comprovante_matricula(aluno_matricula, periodo_letivo)
    
    if not result["success"]:
        raise HTTPException(status_code=404, detail=result["message"])
    
    return result["data"]

@router.get("/historico/{aluno_matricula}")
def obter_historico(
    aluno_matricula: str,
    db: Session = Depends(get_db)
):
    """Fase 7: Obter histórico de matrícula"""
    service = MatriculaService(db)
    result = service.obter_historico_matricula(aluno_matricula)
    
    if not result["success"]:
        raise HTTPException(status_code=404, detail=result["message"])
    
    return result["data"]

@router.get("/turmas-disponiveis/{periodo_letivo}", response_model=List[Turma])
def listar_turmas_disponiveis(
    periodo_letivo: str,
    db: Session = Depends(get_db)
):
    """Listar turmas disponíveis para matrícula"""
    turmas = db.query(TurmaModel).filter(
        TurmaModel.periodo_letivo_codigo == periodo_letivo
    ).all()
    
    return turmas

@router.get("/matriculas-aluno/{aluno_matricula}/{periodo_letivo}", response_model=List[Matricula])
def listar_matriculas_aluno(
    aluno_matricula: str,
    periodo_letivo: str,
    db: Session = Depends(get_db)
):
    """Listar matrículas do aluno em um período"""
    matriculas = db.query(MatriculaModel).join(TurmaModel).filter(
        MatriculaModel.aluno_matricula == aluno_matricula,
        TurmaModel.periodo_letivo_codigo == periodo_letivo
    ).all()
    
    return matriculas