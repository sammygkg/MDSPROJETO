from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, ForeignKey, Text, Time
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()

class Aluno(Base):
    __tablename__ = "alunos"
    
    matricula = Column(String, primary_key=True)
    nome = Column(String, nullable=False)
    ira = Column(Float, default=0.0)
    email = Column(String)
    data_admissao = Column(DateTime, default=datetime.utcnow)
    curso_codigo = Column(String, ForeignKey("cursos.codigo"))
    
    curso = relationship("Curso", back_populates="alunos")
    matriculas = relationship("Matricula", back_populates="aluno")
    solicitacoes = relationship("SolicitacaoMatricula", back_populates="aluno")

class Professor(Base):
    __tablename__ = "professores"
    
    codigo = Column(String, primary_key=True)
    nome = Column(String, nullable=False)
    email = Column(String)
    departamento = Column(String)
    
    turmas = relationship("Turma", secondary="professor_turma", back_populates="professores")

class Curso(Base):
    __tablename__ = "cursos"
    
    codigo = Column(String, primary_key=True)
    nome = Column(String, nullable=False)
    creditos_minimos = Column(Integer, default=0)
    creditos_maximos = Column(Integer, default=30)
    
    alunos = relationship("Aluno", back_populates="curso")
    disciplinas = relationship("Disciplina", secondary="curriculo", back_populates="cursos")

class Disciplina(Base):
    __tablename__ = "disciplinas"
    
    codigo = Column(String, primary_key=True)
    nome = Column(String, nullable=False)
    creditos = Column(Integer, nullable=False)
    carga_horaria = Column(Integer, nullable=False)
    ementa = Column(Text)
    
    cursos = relationship("Curso", secondary="curriculo", back_populates="disciplinas")
    prerequisitos = relationship("Disciplina", 
                               secondary="prerequisitos",
                               primaryjoin="Disciplina.codigo==prerequisitos.c.disciplina_codigo",
                               secondaryjoin="Disciplina.codigo==prerequisitos.c.prerequisito_codigo",
                               back_populates="dependentes")
    dependentes = relationship("Disciplina",
                             secondary="prerequisitos", 
                             primaryjoin="Disciplina.codigo==prerequisitos.c.prerequisito_codigo",
                             secondaryjoin="Disciplina.codigo==prerequisitos.c.disciplina_codigo",
                             back_populates="prerequisitos")
    turmas = relationship("Turma", back_populates="disciplina")

class PeriodoLetivo(Base):
    __tablename__ = "periodos_letivos"
    
    codigo = Column(String, primary_key=True)  # ex: "2023/1"
    ano = Column(Integer, nullable=False)
    semestre = Column(Integer, nullable=False)  # 1 ou 2
    data_inicio = Column(DateTime)
    data_fim = Column(DateTime)
    
    turmas = relationship("Turma", back_populates="periodo_letivo")

class Turma(Base):
    __tablename__ = "turmas"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    codigo = Column(String, nullable=False)  # ex: "A", "B", "C"
    vagas_ofertadas = Column(Integer, nullable=False)
    vagas_ocupadas = Column(Integer, default=0)
    disciplina_codigo = Column(String, ForeignKey("disciplinas.codigo"))
    periodo_letivo_codigo = Column(String, ForeignKey("periodos_letivos.codigo"))
    
    disciplina = relationship("Disciplina", back_populates="turmas")
    periodo_letivo = relationship("PeriodoLetivo", back_populates="turmas")
    professores = relationship("Professor", secondary="professor_turma", back_populates="turmas")
    horarios = relationship("Horario", back_populates="turma")
    matriculas = relationship("Matricula", back_populates="turma")
    solicitacoes = relationship("SolicitacaoMatricula", back_populates="turma")
    
    @property
    def vagas_disponiveis(self):
        return self.vagas_ofertadas - self.vagas_ocupadas

class Horario(Base):
    __tablename__ = "horarios"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    dia_semana = Column(String, nullable=False)  # Segunda, Terça, etc.
    hora_inicio = Column(Time, nullable=False)
    hora_fim = Column(Time, nullable=False)
    turma_id = Column(Integer, ForeignKey("turmas.id"))
    
    turma = relationship("Turma", back_populates="horarios")

class Matricula(Base):
    __tablename__ = "matriculas"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    aluno_matricula = Column(String, ForeignKey("alunos.matricula"))
    turma_id = Column(Integer, ForeignKey("turmas.id"))
    status = Column(String, default="PreMatricula")  # PreMatricula, Confirmada, Cancelada
    data_matricula = Column(DateTime, default=datetime.utcnow)
    nota_final = Column(Float)
    situacao = Column(String)  # Aprovado, Reprovado, Cursando
    
    aluno = relationship("Aluno", back_populates="matriculas")
    turma = relationship("Turma", back_populates="matriculas")

class SolicitacaoMatricula(Base):
    __tablename__ = "solicitacoes_matricula"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    aluno_matricula = Column(String, ForeignKey("alunos.matricula"))
    turma_id = Column(Integer, ForeignKey("turmas.id"))
    prioridade = Column(Integer, nullable=False)  # 1-10
    fase = Column(String, nullable=False)  # Matricula, Rematricula, Extraordinaria
    status = Column(String, default="Pendente")  # Pendente, Aprovada, Rejeitada
    motivo_rejeicao = Column(String)
    data_solicitacao = Column(DateTime, default=datetime.utcnow)
    
    aluno = relationship("Aluno", back_populates="solicitacoes")
    turma = relationship("Turma", back_populates="solicitacoes")

# Tabelas de associação
from sqlalchemy import Table

curriculo = Table('curriculo', Base.metadata,
    Column('curso_codigo', String, ForeignKey('cursos.codigo')),
    Column('disciplina_codigo', String, ForeignKey('disciplinas.codigo'))
)

prerequisitos = Table('prerequisitos', Base.metadata,
    Column('disciplina_codigo', String, ForeignKey('disciplinas.codigo')),
    Column('prerequisito_codigo', String, ForeignKey('disciplinas.codigo'))
)

professor_turma = Table('professor_turma', Base.metadata,
    Column('professor_codigo', String, ForeignKey('professores.codigo')),
    Column('turma_id', Integer, ForeignKey('turmas.id'))
)