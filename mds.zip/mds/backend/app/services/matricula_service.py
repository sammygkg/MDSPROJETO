from sqlalchemy.orm import Session
from sqlalchemy import and_, or_
from typing import List, Dict, Tuple
from datetime import datetime, time
import random

from ..models.models import Aluno, Turma, Disciplina, Matricula, SolicitacaoMatricula, Horario
from ..schemas.schemas import SolicitacaoMatriculaCreate, MatriculaCreate

class MatriculaService:
    def __init__(self, db: Session):
        self.db = db

    def confirmar_pre_matricula(self, aluno_matricula: str, turma_id: int, aceitar: bool) -> Dict:
        """Fase 2: Confirmar ou rejeitar pré-matrícula"""
        
        matricula = self.db.query(Matricula).filter(
            and_(
                Matricula.aluno_matricula == aluno_matricula,
                Matricula.turma_id == turma_id,
                Matricula.status == "PreMatricula"
            )
        ).first()
        
        if not matricula:
            return {"success": False, "message": "Pré-matrícula não encontrada"}
        
        if aceitar:
            matricula.status = "Confirmada"
            turma = self.db.query(Turma).filter(Turma.id == turma_id).first()
            if turma:
                turma.vagas_ocupadas += 1
            message = "Matrícula confirmada com sucesso"
        else:
            matricula.status = "Cancelada"
            message = "Pré-matrícula rejeitada"
        
        self.db.commit()
        return {"success": True, "message": message}

    def solicitar_turma_adicional(self, solicitacao_data: SolicitacaoMatriculaCreate) -> Dict:
        """Fase 2, 4, 6: Solicitar turma adicional"""
        
        # Verificar se já existe solicitação para a mesma turma na mesma fase
        existing = self.db.query(SolicitacaoMatricula).filter(
            and_(
                SolicitacaoMatricula.aluno_matricula == solicitacao_data.aluno_matricula,
                SolicitacaoMatricula.turma_id == solicitacao_data.turma_id,
                SolicitacaoMatricula.fase == solicitacao_data.fase,
                SolicitacaoMatricula.status == "Pendente"
            )
        ).first()
        
        if existing:
            return {"success": False, "message": "Solicitação já existe para esta turma"}
        
        # Verificar se a prioridade já está sendo usada
        priority_exists = self.db.query(SolicitacaoMatricula).filter(
            and_(
                SolicitacaoMatricula.aluno_matricula == solicitacao_data.aluno_matricula,
                SolicitacaoMatricula.prioridade == solicitacao_data.prioridade,
                SolicitacaoMatricula.fase == solicitacao_data.fase,
                SolicitacaoMatricula.status == "Pendente"
            )
        ).first()
        
        if priority_exists:
            return {"success": False, "message": "Prioridade já está sendo usada"}
        
        solicitacao = SolicitacaoMatricula(**solicitacao_data.dict())
        self.db.add(solicitacao)
        self.db.commit()
        
        return {"success": True, "message": "Solicitação criada com sucesso"}

    def verificar_elegibilidade(self, aluno_matricula: str, turma_id: int) -> Tuple[bool, str]:
        """R1: Verificar elegibilidade da solicitação"""
        
        aluno = self.db.query(Aluno).filter(Aluno.matricula == aluno_matricula).first()
        turma = self.db.query(Turma).filter(Turma.id == turma_id).first()
        
        if not aluno or not turma:
            return False, "Aluno ou turma não encontrados"
        
        disciplina = turma.disciplina
        
        # Verificar se a disciplina está no currículo do curso do aluno
        if disciplina not in aluno.curso.disciplinas:
            return False, "Aluno não pode se matricular nesta disciplina"
        
        # Verificar se o aluno já foi aprovado na disciplina
        aprovacao_anterior = self.db.query(Matricula).filter(
            and_(
                Matricula.aluno_matricula == aluno_matricula,
                Matricula.turma.has(Turma.disciplina_codigo == disciplina.codigo),
                Matricula.situacao == "Aprovado"
            )
        ).first()
        
        if aprovacao_anterior:
            return False, "Aluno não pode se matricular nesta disciplina"
        
        # Verificar pré-requisitos
        for prerequisito in disciplina.prerequisitos:
            prerequisito_cumprido = self.db.query(Matricula).filter(
                and_(
                    Matricula.aluno_matricula == aluno_matricula,
                    Matricula.turma.has(Turma.disciplina_codigo == prerequisito.codigo),
                    Matricula.situacao == "Aprovado"
                )
            ).first()
            
            if not prerequisito_cumprido:
                return False, "Aluno não possui todos os pré-requisitos da disciplina"
        
        return True, "Solicitação elegível"

    def verificar_restricoes_aluno(self, aluno_matricula: str, turma_id: int) -> Tuple[bool, str]:
        """R3: Verificar restrições específicas do aluno"""
        
        aluno = self.db.query(Aluno).filter(Aluno.matricula == aluno_matricula).first()
        turma = self.db.query(Turma).filter(Turma.id == turma_id).first()
        
        # Verificar limite de créditos
        creditos_atuais = self.db.query(Matricula).join(Turma).join(Disciplina).filter(
            and_(
                Matricula.aluno_matricula == aluno_matricula,
                Matricula.status.in_(["Confirmada", "PreMatricula"])
            )
        ).with_entities(Disciplina.creditos).all()
        
        total_creditos = sum([c[0] for c in creditos_atuais]) + turma.disciplina.creditos
        
        if total_creditos > aluno.curso.creditos_maximos:
            return False, "Aluno excede a quantidade máxima de créditos em um período"
        
        # Verificar se já está matriculado na disciplina
        matricula_existente = self.db.query(Matricula).filter(
            and_(
                Matricula.aluno_matricula == aluno_matricula,
                Matricula.turma.has(Turma.disciplina_codigo == turma.disciplina.codigo),
                Matricula.status.in_(["Confirmada", "PreMatricula"])
            )
        ).first()
        
        if matricula_existente:
            return False, "Aluno já matriculado nesta disciplina no período"
        
        # Verificar conflito de horário
        horarios_turma = self.db.query(Horario).filter(Horario.turma_id == turma_id).all()
        
        matriculas_aluno = self.db.query(Matricula).filter(
            and_(
                Matricula.aluno_matricula == aluno_matricula,
                Matricula.status.in_(["Confirmada", "PreMatricula"])
            )
        ).all()
        
        for matricula in matriculas_aluno:
            horarios_matricula = self.db.query(Horario).filter(
                Horario.turma_id == matricula.turma_id
            ).all()
            
            for h1 in horarios_turma:
                for h2 in horarios_matricula:
                    if (h1.dia_semana == h2.dia_semana and 
                        self._horarios_conflitam(h1.hora_inicio, h1.hora_fim, 
                                               h2.hora_inicio, h2.hora_fim)):
                        return False, "Turma com conflito de horário"
        
        return True, "Sem restrições"

    def _horarios_conflitam(self, inicio1: time, fim1: time, inicio2: time, fim2: time) -> bool:
        """Verificar se dois horários conflitam"""
        return not (fim1 <= inicio2 or fim2 <= inicio1)

    def processar_solicitacoes_batch(self, fase: str) -> Dict:
        """Fase 3, 5: Processar solicitações em lote"""
        
        solicitacoes = self.db.query(SolicitacaoMatricula).filter(
            and_(
                SolicitacaoMatricula.fase == fase,
                SolicitacaoMatricula.status == "Pendente"
            )
        ).all()
        
        resultados = {
            "processadas": 0,
            "aprovadas": 0,
            "rejeitadas": 0,
            "detalhes": []
        }
        
        # R1: Verificar elegibilidade
        solicitacoes_elegiveis = []
        for solicitacao in solicitacoes:
            elegivel, motivo = self.verificar_elegibilidade(
                solicitacao.aluno_matricula, 
                solicitacao.turma_id
            )
            
            if elegivel:
                solicitacoes_elegiveis.append(solicitacao)
            else:
                solicitacao.status = "Rejeitada"
                solicitacao.motivo_rejeicao = motivo
                resultados["rejeitadas"] += 1
                resultados["detalhes"].append({
                    "aluno": solicitacao.aluno_matricula,
                    "turma": solicitacao.turma_id,
                    "status": "Rejeitada",
                    "motivo": motivo
                })
        
        # R2: Agrupar por turma e ordenar por IRA e data de admissão
        turmas_solicitadas = {}
        for solicitacao in solicitacoes_elegiveis:
            turma_id = solicitacao.turma_id
            if turma_id not in turmas_solicitadas:
                turmas_solicitadas[turma_id] = []
            turmas_solicitadas[turma_id].append(solicitacao)
        
        # Ordenar solicitações por turma
        for turma_id in turmas_solicitadas:
            turmas_solicitadas[turma_id].sort(
                key=lambda s: (-s.aluno.ira, s.aluno.data_admissao, random.random())
            )
        
        # R3: Processar solicitações por aluno, respeitando prioridades
        alteracoes = True
        while alteracoes:
            alteracoes = False
            
            for solicitacao in solicitacoes_elegiveis:
                if solicitacao.status != "Pendente":
                    continue
                
                # Verificar restrições do aluno
                valido, motivo = self.verificar_restricoes_aluno(
                    solicitacao.aluno_matricula,
                    solicitacao.turma_id
                )
                
                if not valido:
                    solicitacao.status = "Rejeitada"
                    solicitacao.motivo_rejeicao = motivo
                    self._remover_da_lista_prioridade(solicitacao, turmas_solicitadas)
                    alteracoes = True
                    resultados["rejeitadas"] += 1
                    continue
                
                # Verificar se há vaga disponível
                turma = self.db.query(Turma).filter(Turma.id == solicitacao.turma_id).first()
                posicao = self._obter_posicao_lista_prioridade(solicitacao, turmas_solicitadas)
                
                if posicao <= turma.vagas_disponiveis:
                    # Aprovar solicitação
                    solicitacao.status = "Aprovada"
                    
                    # Criar matrícula
                    nova_matricula = Matricula(
                        aluno_matricula=solicitacao.aluno_matricula,
                        turma_id=solicitacao.turma_id,
                        status="Confirmada"
                    )
                    self.db.add(nova_matricula)
                    
                    # Atualizar vagas ocupadas
                    turma.vagas_ocupadas += 1
                    
                    alteracoes = True
                    resultados["aprovadas"] += 1
                    resultados["detalhes"].append({
                        "aluno": solicitacao.aluno_matricula,
                        "turma": solicitacao.turma_id,
                        "status": "Aprovada",
                        "motivo": "Matrícula efetivada"
                    })
        
        # R4: Rejeitar solicitações restantes
        for solicitacao in solicitacoes_elegiveis:
            if solicitacao.status == "Pendente":
                solicitacao.status = "Rejeitada"
                solicitacao.motivo_rejeicao = "Não há vagas disponíveis para esta turma"
                resultados["rejeitadas"] += 1
        
        resultados["processadas"] = len(solicitacoes)
        self.db.commit()
        
        return resultados

    def _remover_da_lista_prioridade(self, solicitacao: SolicitacaoMatricula, turmas_solicitadas: Dict):
        """Remove solicitação da lista de prioridade"""
        turma_id = solicitacao.turma_id
        if turma_id in turmas_solicitadas and solicitacao in turmas_solicitadas[turma_id]:
            turmas_solicitadas[turma_id].remove(solicitacao)

    def _obter_posicao_lista_prioridade(self, solicitacao: SolicitacaoMatricula, turmas_solicitadas: Dict) -> int:
        """Obtém a posição da solicitação na lista de prioridade da turma"""
        turma_id = solicitacao.turma_id
        if turma_id in turmas_solicitadas:
            try:
                return turmas_solicitadas[turma_id].index(solicitacao) + 1
            except ValueError:
                return float('inf')
        return float('inf')

    def matricula_extraordinaria(self, solicitacao_data: SolicitacaoMatriculaCreate) -> Dict:
        """Fase 6: Matrícula extraordinária (processamento imediato)"""
        
        # Verificar elegibilidade
        elegivel, motivo = self.verificar_elegibilidade(
            solicitacao_data.aluno_matricula, 
            solicitacao_data.turma_id
        )
        
        if not elegivel:
            return {"success": False, "message": motivo}
        
        # Verificar restrições do aluno
        valido, motivo = self.verificar_restricoes_aluno(
            solicitacao_data.aluno_matricula,
            solicitacao_data.turma_id
        )
        
        if not valido:
            return {"success": False, "message": motivo}
        
        # Verificar se há vaga disponível
        turma = self.db.query(Turma).filter(Turma.id == solicitacao_data.turma_id).first()
        
        if turma.vagas_disponiveis <= 0:
            return {"success": False, "message": "Não há vagas disponíveis para esta turma"}
        
        # Criar matrícula imediatamente
        nova_matricula = Matricula(
            aluno_matricula=solicitacao_data.aluno_matricula,
            turma_id=solicitacao_data.turma_id,
            status="Confirmada"
        )
        self.db.add(nova_matricula)
        
        # Atualizar vagas ocupadas
        turma.vagas_ocupadas += 1
        
        self.db.commit()
        
        return {"success": True, "message": "Matrícula extraordinária realizada com sucesso"}

    def cancelar_matricula(self, aluno_matricula: str, turma_id: int) -> Dict:
        """Fase 4: Cancelar matrícula existente"""
        
        matricula = self.db.query(Matricula).filter(
            and_(
                Matricula.aluno_matricula == aluno_matricula,
                Matricula.turma_id == turma_id,
                Matricula.status == "Confirmada"
            )
        ).first()
        
        if not matricula:
            return {"success": False, "message": "Matrícula não encontrada"}
        
        matricula.status = "Cancelada"
        
        # Liberar vaga
        turma = self.db.query(Turma).filter(Turma.id == turma_id).first()
        if turma and turma.vagas_ocupadas > 0:
            turma.vagas_ocupadas -= 1
        
        self.db.commit()
        
        return {"success": True, "message": "Matrícula cancelada com sucesso"}

    def obter_comprovante_matricula(self, aluno_matricula: str, periodo_letivo_codigo: str) -> Dict:
        """Fase 7: Gerar comprovante de matrícula"""
        
        aluno = self.db.query(Aluno).filter(Aluno.matricula == aluno_matricula).first()
        if not aluno:
            return {"success": False, "message": "Aluno não encontrado"}
        
        matriculas = self.db.query(Matricula).join(Turma).filter(
            and_(
                Matricula.aluno_matricula == aluno_matricula,
                Turma.periodo_letivo_codigo == periodo_letivo_codigo,
                Matricula.status == "Confirmada"
            )
        ).all()
        
        total_creditos = sum([m.turma.disciplina.creditos for m in matriculas])
        
        comprovante = {
            "aluno": {
                "matricula": aluno.matricula,
                "nome": aluno.nome,
                "curso": aluno.curso.nome if aluno.curso else None
            },
            "periodo_letivo": periodo_letivo_codigo,
            "matriculas": [
                {
                    "disciplina_codigo": m.turma.disciplina.codigo,
                    "disciplina_nome": m.turma.disciplina.nome,
                    "turma_codigo": m.turma.codigo,
                    "creditos": m.turma.disciplina.creditos,
                    "professores": [p.nome for p in m.turma.professores],
                    "horarios": [
                        {
                            "dia_semana": h.dia_semana,
                            "hora_inicio": h.hora_inicio.strftime("%H:%M"),
                            "hora_fim": h.hora_fim.strftime("%H:%M")
                        } for h in m.turma.horarios
                    ]
                } for m in matriculas
            ],
            "total_creditos": total_creditos,
            "data_geracao": datetime.now()
        }
        
        return {"success": True, "data": comprovante}

    def obter_historico_matricula(self, aluno_matricula: str) -> Dict:
        """Fase 7: Obter histórico de processamento de matrícula"""
        
        solicitacoes = self.db.query(SolicitacaoMatricula).filter(
            SolicitacaoMatricula.aluno_matricula == aluno_matricula
        ).order_by(SolicitacaoMatricula.data_solicitacao.desc()).all()
        
        historico = [
            {
                "id": s.id,
                "disciplina_codigo": s.turma.disciplina.codigo,
                "disciplina_nome": s.turma.disciplina.nome,
                "turma_codigo": s.turma.codigo,
                "prioridade": s.prioridade,
                "fase": s.fase,
                "status": s.status,
                "motivo_rejeicao": s.motivo_rejeicao,
                "data_solicitacao": s.data_solicitacao
            } for s in solicitacoes
        ]
        
        return {"success": True, "data": historico}