from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime, time

class HorarioBase(BaseModel):
    dia_semana: str
    hora_inicio: time
    hora_fim: time

class HorarioCreate(HorarioBase):
    pass

class Horario(HorarioBase):
    id: int
    turma_id: int

    class Config:
        from_attributes = True

class ProfessorBase(BaseModel):
    codigo: str
    nome: str
    email: Optional[str] = None
    departamento: Optional[str] = None

class ProfessorCreate(ProfessorBase):
    pass

class Professor(ProfessorBase):
    class Config:
        from_attributes = True

class DisciplinaBase(BaseModel):
    codigo: str
    nome: str
    creditos: int
    carga_horaria: int
    ementa: Optional[str] = None

class DisciplinaCreate(DisciplinaBase):
    pass

class Disciplina(DisciplinaBase):
    prerequisitos: List['Disciplina'] = []

    class Config:
        from_attributes = True

class CursoBase(BaseModel):
    codigo: str
    nome: str
    creditos_minimos: int = 0
    creditos_maximos: int = 30

class CursoCreate(CursoBase):
    pass

class Curso(CursoBase):
    disciplinas: List[Disciplina] = []

    class Config:
        from_attributes = True

class AlunoBase(BaseModel):
    matricula: str
    nome: str
    ira: float = 0.0
    email: Optional[str] = None
    curso_codigo: str

class AlunoCreate(AlunoBase):
    pass

class Aluno(AlunoBase):
    data_admissao: datetime
    curso: Optional[Curso] = None

    class Config:
        from_attributes = True

class PeriodoLetivoBase(BaseModel):
    codigo: str
    ano: int
    semestre: int
    data_inicio: Optional[datetime] = None
    data_fim: Optional[datetime] = None

class PeriodoLetivoCreate(PeriodoLetivoBase):
    pass

class PeriodoLetivo(PeriodoLetivoBase):
    class Config:
        from_attributes = True

class TurmaBase(BaseModel):
    codigo: str
    vagas_ofertadas: int
    disciplina_codigo: str
    periodo_letivo_codigo: str

class TurmaCreate(TurmaBase):
    pass

class Turma(TurmaBase):
    id: int
    vagas_ocupadas: int = 0
    disciplina: Optional[Disciplina] = None
    periodo_letivo: Optional[PeriodoLetivo] = None
    professores: List[Professor] = []
    horarios: List[Horario] = []

    @property
    def vagas_disponiveis(self):
        return self.vagas_ofertadas - self.vagas_ocupadas

    class Config:
        from_attributes = True

class MatriculaBase(BaseModel):
    aluno_matricula: str
    turma_id: int
    status: str = "PreMatricula"

class MatriculaCreate(MatriculaBase):
    pass

class Matricula(MatriculaBase):
    id: int
    data_matricula: datetime
    nota_final: Optional[float] = None
    situacao: Optional[str] = None
    aluno: Optional[Aluno] = None
    turma: Optional[Turma] = None

    class Config:
        from_attributes = True

class SolicitacaoMatriculaBase(BaseModel):
    aluno_matricula: str
    turma_id: int
    prioridade: int
    fase: str

class SolicitacaoMatriculaCreate(SolicitacaoMatriculaBase):
    pass

class SolicitacaoMatricula(SolicitacaoMatriculaBase):
    id: int
    status: str = "Pendente"
    motivo_rejeicao: Optional[str] = None
    data_solicitacao: datetime
    aluno: Optional[Aluno] = None
    turma: Optional[Turma] = None

    class Config:
        from_attributes = True

class MatriculaResponse(BaseModel):
    success: bool
    message: str
    data: Optional[dict] = None

class ComprovanteMatricula(BaseModel):
    aluno: Aluno
    periodo_letivo: str
    matriculas: List[Matricula]
    total_creditos: int
    data_geracao: datetime

# Update forward references
Disciplina.model_rebuild()