from app.core.database import SessionLocal, engine
from app.models.models import Base, Aluno, Professor, Curso, Disciplina, PeriodoLetivo, Turma, Horario, Matricula
from app.models.models import curriculo, prerequisitos, professor_turma
from datetime import datetime, time
from sqlalchemy.orm import Session

# Create all tables
Base.metadata.create_all(bind=engine)

def populate_database():
    db = SessionLocal()
    
    try:
        # Criar cursos
        curso_cc = Curso(
            codigo="116",
            nome="Ciência da Computação",
            creditos_minimos=180,
            creditos_maximos=28
        )
        curso_ee = Curso(
            codigo="123",
            nome="Engenharia Elétrica",
            creditos_minimos=240,
            creditos_maximos=30
        )
        
        db.add_all([curso_cc, curso_ee])
        
        # Criar disciplinas
        disciplinas = [
            Disciplina(codigo="MAT0025", nome="Cálculo 1", creditos=6, carga_horaria=90),
            Disciplina(codigo="MAT0026", nome="Cálculo 2", creditos=6, carga_horaria=90),
            Disciplina(codigo="MAT0031", nome="Álgebra Linear", creditos=4, carga_horaria=60),
            Disciplina(codigo="CIC0004", nome="Algoritmos e Programação de Computadores", creditos=6, carga_horaria=90),
            Disciplina(codigo="CIC0090", nome="Estruturas de Dados", creditos=4, carga_horaria=60),
            Disciplina(codigo="ENE0454", nome="Introdução à Engenharia de Redes de Comunicação", creditos=4, carga_horaria=60),
            Disciplina(codigo="ENE0031", nome="Circuitos Elétricos", creditos=6, carga_horaria=90),
        ]
        
        for disciplina in disciplinas:
            db.add(disciplina)
        
        db.flush()  # Para obter os IDs
        
        # Definir pré-requisitos
        calc1 = db.query(Disciplina).filter(Disciplina.codigo == "MAT0025").first()
        calc2 = db.query(Disciplina).filter(Disciplina.codigo == "MAT0026").first()
        apc = db.query(Disciplina).filter(Disciplina.codigo == "CIC0004").first()
        ed = db.query(Disciplina).filter(Disciplina.codigo == "CIC0090").first()
        
        # Cálculo 2 tem Cálculo 1 como pré-requisito
        calc2.prerequisitos.append(calc1)
        # Estruturas de Dados tem APC como pré-requisito
        ed.prerequisitos.append(apc)
        
        # Associar disciplinas aos cursos
        for disciplina in disciplinas:
            if disciplina.codigo.startswith("CIC") or disciplina.codigo.startswith("MAT"):
                curso_cc.disciplinas.append(disciplina)
            if disciplina.codigo.startswith("ENE") or disciplina.codigo.startswith("MAT"):
                curso_ee.disciplinas.append(disciplina)
        
        # Criar professores
        professores = [
            Professor(codigo="PROF001", nome="Prof. João Silva", email="joao@unb.br", departamento="CIC"),
            Professor(codigo="PROF002", nome="Prof. Maria Santos", email="maria@unb.br", departamento="MAT"),
            Professor(codigo="PROF003", nome="Prof. Pedro Alves", email="pedro@unb.br", departamento="ENE"),
        ]
        
        for professor in professores:
            db.add(professor)
        
        # Criar período letivo
        periodo = PeriodoLetivo(
            codigo="2024/1",
            ano=2024,
            semestre=1,
            data_inicio=datetime(2024, 3, 1),
            data_fim=datetime(2024, 7, 15)
        )
        db.add(periodo)
        
        db.flush()
        
        # Criar turmas
        turmas_data = [
            ("MAT0025", "A", 60, "PROF002"),
            ("MAT0025", "B", 60, "PROF002"),
            ("CIC0004", "A", 50, "PROF001"),
            ("ENE0454", "A", 60, "PROF003"),
            ("MAT0031", "A", 40, "PROF002"),
        ]
        
        turmas = []
        for disc_codigo, turma_codigo, vagas, prof_codigo in turmas_data:
            turma = Turma(
                codigo=turma_codigo,
                vagas_ofertadas=vagas,
                vagas_ocupadas=0,
                disciplina_codigo=disc_codigo,
                periodo_letivo_codigo="2024/1"
            )
            db.add(turma)
            turmas.append(turma)
        
        db.flush()
        
        # Associar professores às turmas
        for i, (_, _, _, prof_codigo) in enumerate(turmas_data):
            professor = db.query(Professor).filter(Professor.codigo == prof_codigo).first()
            turmas[i].professores.append(professor)
        
        # Criar horários para as turmas
        horarios_data = [
            (0, "Segunda", time(8, 0), time(10, 0)),  # MAT0025 A
            (0, "Quarta", time(8, 0), time(10, 0)),
            (1, "Segunda", time(10, 0), time(12, 0)),  # MAT0025 B
            (1, "Quarta", time(10, 0), time(12, 0)),
            (2, "Terça", time(14, 0), time(16, 0)),  # CIC0004 A
            (2, "Quinta", time(14, 0), time(16, 0)),
            (3, "Quarta", time(8, 0), time(10, 0)),  # ENE0454 A
            (4, "Segunda", time(16, 0), time(18, 0)),  # MAT0031 A
        ]
        
        for turma_idx, dia, inicio, fim in horarios_data:
            horario = Horario(
                dia_semana=dia,
                hora_inicio=inicio,
                hora_fim=fim,
                turma_id=turmas[turma_idx].id
            )
            db.add(horario)
        
        # Criar alunos
        alunos = [
            Aluno(matricula="190001", nome="Ana Costa", ira=8.5, email="ana@aluno.unb.br", curso_codigo="116"),
            Aluno(matricula="190002", nome="Bruno Lima", ira=7.2, email="bruno@aluno.unb.br", curso_codigo="116"),
            Aluno(matricula="190003", nome="Carlos Pereira", ira=9.1, email="carlos@aluno.unb.br", curso_codigo="123"),
            Aluno(matricula="190004", nome="Diana Silva", ira=6.8, email="diana@aluno.unb.br", curso_codigo="123"),
            Aluno(matricula="12345", nome="Pedro", ira=7.5, email="pedro@aluno.unb.br", curso_codigo="123"),  # Para testar com o código existente
        ]
        
        for aluno in alunos:
            db.add(aluno)
        
        db.flush()
        
        # Criar algumas pré-matrículas para os alunos
        pre_matriculas = [
            ("190001", 0, "PreMatricula"),  # Ana em MAT0025 A
            ("190001", 2, "PreMatricula"),  # Ana em CIC0004 A
            ("190002", 1, "PreMatricula"),  # Bruno em MAT0025 B
            ("190003", 3, "PreMatricula"),  # Carlos em ENE0454 A
            ("12345", 3, "PreMatricula"),   # Pedro em ENE0454 A
        ]
        
        for aluno_mat, turma_idx, status in pre_matriculas:
            matricula = Matricula(
                aluno_matricula=aluno_mat,
                turma_id=turmas[turma_idx].id,
                status=status
            )
            db.add(matricula)
            
            # Atualizar vagas ocupadas se for pré-matrícula
            if status == "PreMatricula":
                turmas[turma_idx].vagas_ocupadas += 1
        
        db.commit()
        print("Database populated successfully!")
        
    except Exception as e:
        print(f"Error populating database: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    populate_database()