#!/usr/bin/env python3
"""Quick test of the SIGAA API"""

import requests
import json
from app.core.database import SessionLocal
from app.models.models import Aluno, Turma

def test_database():
    """Test database connection and data"""
    print("Testing database connection...")
    db = SessionLocal()
    try:
        # Test getting students
        alunos = db.query(Aluno).all()
        print(f"✓ Found {len(alunos)} students in database")
        
        # Test getting classes
        turmas = db.query(Turma).all()
        print(f"✓ Found {len(turmas)} classes in database")
        
        # Show sample data
        if alunos:
            print(f"Sample student: {alunos[0].nome} ({alunos[0].matricula})")
        
        if turmas:
            print(f"Sample class: {turmas[0].disciplina.nome} - Turma {turmas[0].codigo}")
            
        return True
    except Exception as e:
        print(f"✗ Database error: {e}")
        return False
    finally:
        db.close()

def test_api_endpoints():
    """Test API endpoints"""
    base_url = "http://localhost:8000"
    
    try:
        # Test health endpoint
        response = requests.get(f"{base_url}/health", timeout=5)
        if response.status_code == 200:
            print("✓ API health check passed")
            return True
        else:
            print(f"✗ API health check failed: {response.status_code}")
            return False
    except requests.exceptions.RequestException as e:
        print(f"✗ Cannot connect to API: {e}")
        return False

if __name__ == "__main__":
    print("=== SIGAA API Test ===")
    
    # Test database
    db_ok = test_database()
    
    # Test API if database is working
    if db_ok:
        print("\nTesting API endpoints...")
        api_ok = test_api_endpoints()
        
        if api_ok:
            print("\n✓ All tests passed! System is ready.")
        else:
            print("\n⚠ Database OK, but API server not running.")
            print("Start the API with: uvicorn main:app --reload")
    else:
        print("\n✗ Database connection failed. Check your setup.")
        
    print("\n=== Test Complete ===")